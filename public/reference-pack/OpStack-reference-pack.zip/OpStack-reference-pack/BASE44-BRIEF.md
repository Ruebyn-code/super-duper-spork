# Recreate the current OpStack platform

Source repository: https://github.com/Ruebyn-code/super-duper-spork
Product source revision: d854bf1198622667e73047c43314460f60c53b6f
Captured 2026-11-03T10:51:10.458Z using temporary demo data and native app screens. The trading examples use 26 October 2026. These are visual references, not production records.

## Instructions to give Base44

Use the supplied source repository as the source of truth, and this screenshot pack as a visual reference. Preserve the existing company styling, terminology, navigation, desktop/phone behaviour, workflows, permissions, calculations and history. Reuse tested business logic wherever compatible.

First inspect the Node.js backend, authentication, file storage, background jobs and webhooks. Produce a feature inventory, a compatibility assessment, a list of unsupported capabilities, and a staged migration plan before generating a replacement. Do not assume that repository import means the existing backend can run unchanged.

Build one module at a time, starting with accounts, company/location access, then locations, ordering, sales, rosters and the remaining modules. Test against the existing application and its tests. Preserve calculation edge cases, explicit save/review actions, immutable financial and employment records, account-based signing and location-scoped access.

Use demo records while rebuilding. Configure provider connections separately; this archive contains no working provider keys, passwords, sessions or production data. Migrate production records, attachments and relationships only after the rebuilt workflows are verified. Screenshots alone cannot prove behaviour, security, award calculations, legal compliance or provider compatibility.

## How to use the pack

1. Extract the ZIP and open index.html for the searchable offline gallery.
2. Read SCREEN-INDEX.csv or manifest.json to find screenshots by route, role, layout and theme.
3. Upload the relevant screenshot group as you rebuild that module. Keep full-resolution originals.
4. Use FEATURE-GUIDES.md for all 127 written feature workflows.
5. Use assets/design-tokens.json and the supplied fonts/shared CSS as styling references. These are code defaults; saved production company customisations are not exported.
6. Retain the source repository for the full implementation and existing tests. This is a visual reference pack, not a source-code archive or operational backup.

## Coverage

- Checklists & planners: 14 screenshots
- Comms: 10 screenshots
- Getting started: 29 screenshots
- Invoices & expenses: 8 screenshots
- Knowledge Library: 5 screenshots
- Labels: 8 screenshots
- Locations & settings: 56 screenshots
- OpStack intelligence: 6 screenshots
- OpStack owner console: 21 screenshots
- Ordering & stock: 47 screenshots
- Reporting: 8 screenshots
- Rosters & time: 39 screenshots
- Sales & projections: 15 screenshots
- Supplier deliveries: 5 screenshots
- Training: 15 screenshots
- Troubleshooting & support: 1 screenshots

287 screenshots in total, including desktop, phone, dark theme, staff and owner-console examples. Temporary demo dates and example values must not be copied into real operations.
