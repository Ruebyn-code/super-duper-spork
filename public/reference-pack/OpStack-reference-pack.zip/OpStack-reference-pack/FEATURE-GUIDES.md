# OpStack feature workflows

Generic native workflow references. Use the repository for business rules and existing tests.

## Getting started

### Find your way around OpStack

Use the main navigation, permanent left subpage bar and blue account dropdown.

1. Use the main navigation at the top to open a feature. On phones, Home, Rostering, Comms, Checklists and More remain in the bottom bar.
2. Use the permanent bar on the left to switch between that feature’s subpages. Larger screens show labels; phones keep a compact icon bar. The selected subpage stays highlighted.
3. Open the blue account dropdown for User profile, Dark mode, Help & support and your available Settings.
4. Use browser Back and Forward to return to earlier screens. Save or resolve outstanding changes before leaving an editor.

### Switch company or location

Make sure you are working in the correct store.

1. Select the company logo to choose one of your accessible companies.
2. Open the location selector and choose the store you need. The app remembers your last location within each company during your sign-in session.
3. Check the selected company and location before entering sales, counts, orders or settings.
4. Save or discard open drafts when prompted before switching.

- A paired kiosk is fixed to its assigned location. If a company or location is missing, ask a user manager to review your access.

### Understand your Home dashboards

Use a company-styled business overview or a store’s daily dashboard.

Route: `/home`

1. Open the location selector and choose Head Office. Authorised managers can create it by selecting this option if it is missing. It opens without a store setup checklist. Selecting a store shows its Store dashboard; Staff profiles keep an operational dashboard without sales.
2. On Head Office, choose accessible locations and a week. Use Daily or Weekly on the Sales leaderboard; gold, silver and bronze medals and row highlights mark the top three places. Daily has its own date selector. Open a location row to see Reporting for those dates.
3. Your greeting sits at the top of the company-tinted Your work panel. The Home guide and selected store’s details sit beside the dashboard name. On a wide screen, scroll Your work and the dashboard separately. Phones keep their normal scrolling. Review training, agreements and trainer sign-offs. Timesheets to approve shows pending completed timesheets across your accessible locations; choose a location to open its oldest pending week. Daily sales opens the existing entry popup when you have Store sales-entry access. Checklist tasks no longer appear in this side panel. Unread Comms is grouped into Groups, Direct messages and Posts, with avatars and unread badges. Choose an item to open its normal screen. Use Show all for more items; completing work or marking posts read removes them after refresh.
4. On a store dashboard, use Today and This hour for projected sales and labour budget. With roster wage access, Today also shows the full published roster cost for that trading day, including overnight shifts dated to it. Draft changes are excluded; missing wage estimates show unavailable, while no published shifts shows zero. Compare saved hourly sales and review ordering, checklists, published staff shifts and quick links.
5. Use Edit Home on a computer to customise the company layout. Head Office, Store and Staff layouts are independent; existing custom sections and the company’s colours, fonts and logos are retained.

- The Sales leaderboard uses saved revenue: complete Weekly report channels first, otherwise Daily sales. Weekly ranks completed days through yesterday in Melbourne; past weeks include all seven days. Missing days leave a location unranked and show its coverage. Real zeroes can rank, and tied totals share a place. Custom Head Office layouts can add Sales leaderboard through Edit Home. Staff Home does not change permission to open Sales elsewhere. Head Office filters are read-only and never switch the operational location. Sales use complete saved weekly revenue channels where available, otherwise Daily sales; future days are excluded. Financial percentages use saved weekly costs divided by recorded sales, so a partial week may show a high percentage. Food cost uses saved invoices plus confirmed cost transfers, never order totals. Ordering projections keep their normal Sunday rollover and original/updated COGS rules; the Head Office budget excludes carts. Staff on now means published shifts scheduled at this time. Checklist summaries retain the existing audience and date rules. Assigned location managers still see eligible transfer approvals, and the Store daily-sales reminder retains its selected trading location. New administrative Head Office locations need no setup and are excluded from store forecasts. Head Office has no daily-sales entry panel; use Sales → Daily sales with the usual permission.

### Add or change your profile photo

Give your account a recognisable photo.

1. Open the blue account dropdown and choose User profile.
2. Choose a photo and check its square preview.
3. Press Save photo to apply it. Choosing a file alone does not save it.
4. Use the photo removal control to return to initials when needed.

- Authorised user managers can also edit photos in Admin → Users. Your profile shows the company, location and access from your current session.

### Switch between light and dark mode

Set the display theme for your account in this browser.

1. Open the blue account dropdown.
2. Select Dark mode to change the theme.
3. The choice follows you between app pages and synchronises with your other open tabs in this browser.

- Until you choose a mode, the app follows your device preference. Printed reports use the light palette. Company logos and uploaded images keep their original colours.

### Find pages and answers with platform search

Search app features and accessible content from the shared search bar.

1. Use the search bar at the top. On a phone, press the search icon to expand it.
2. Type a page name, item or question, such as “how to make gourmet souvlaki”. Ordinary matches appear as you type.
3. Select a result to open its page, article or matching article section. Available image and video previews come from the accessible content.
4. For an intelligence search, submit the question with the search arrow or Enter without a highlighted result. A clear single match may open automatically; otherwise choose a result.

- Typing ordinary matches uses local search. Submitted intelligence searches use your company’s enabled intelligence settings and request allowance. Results follow your current access.

### Use a shared kiosk

Open the normal app with your own permissions on a paired device.

1. At the kiosk, enter your staff PIN: the last four digits of your saved phone number, including any leading zeroes.
2. Open the feature you need. The app uses your account’s permissions and the device’s assigned location.
3. Use the left navigation rail, expanded search and blue account dropdown to move around.
4. Choose Lock kiosk when finished. The kiosk also locks after two minutes without interaction.

- Clock actions require a fresh PIN check even after unlocking the kiosk. Ask a user manager to correct a missing phone number or duplicate phone ending.

## Ordering & stock

### Place an order

Build a cart and double-check it before submitting.

Route: `/`

1. Select the correct location, then open Ordering → Catalogue.
2. Choose a supplier or search for an item. Enter quantities in the item’s displayed ordering unit and add them to the cart.
3. Open the floating Cart button and check supplier groups, quantities, estimates and delivery dates. Add separate notes under each supplier; use Notes for all suppliers for shared instructions.
4. Press Place order to open Double check your order. Review the breakdown, then press the final Place order button.
5. Read each supplier’s sending result and use Order history to review the saved order.

- A saved order and a sent supplier email are separate outcomes. “Submitted” means the sending service accepted the request, rather than proof the supplier read it.

### Use the cart across Ordering pages

Keep one cart while counting, reviewing history or managing stock.

Route: `/#cart`

1. Use the floating Cart button on Catalogue, Stock count, Order history, Transfers or stock-management pages.
2. Adjust quantities, remove items or enter notes under each supplier. Supplier notes stay with this user and location across Ordering pages. Stock count’s Add to cart uses the same cart.
3. Check the weekly budget and supplier delivery guidance before ordering.
4. Cancel the final review if you need to change anything; your cart and notes remain available.

- Carts are separate for each user and location in this browser. Placing or editing quantities requires order-placing permission. Opening the cart does not place an order.

### Find, edit, add or delete past orders

Keep order history complete for the selected location.

Route: `/order-history`

1. Open Ordering → Order history. Filter by dates, supplier or order reference and choose View order.
2. To correct a placed order, select Edit order. Change items, quantities, unit prices, reference, shared notes or separate supplier notes, then select Save changes.
3. To add a missed order, choose Record past order, enter its original date and use the supplier/category cards to add items.
4. Review quantities and historical prices, then choose Save to history. This records the order without emailing the supplier.
5. To remove an incorrect order, open its details, select Delete order and confirm.

- Editing, adding and deleting require order-placing permission. Edits retain the original order date and a private audit, update order-based costs and usage, and send no supplier email or confirmation. Invoice-based weekly expenses keep their saved values. Pending prices may remain blank; zero is a known zero price.
- If an order, its prices or delivery tracking changes while editing, your draft is kept. Reload latest explicitly discards that draft and opens the current order. An uncertain save freezes its details for the same-request retry.
- Deleting excludes the order from order-based budgets, usage and reports; it does not cancel an order with a supplier. Orders still being sent cannot be edited or deleted. A received supplier must retain at least one item.

### Enter and save a stock count

Use compact rows to record the stock physically present.

Route: `/stock-count#new`

1. Open Ordering → Stock count and select New count. Check the count date.
2. Choose Group by → Area or Supplier, then filter or search. Enter quantities next to each item; leave uncounted items blank and enter 0 for none.
3. Use Enter, Down or Right to move to the next visible count field. Up, Left or Shift+Enter moves back.
4. Review the recommended order beside Add to cart. Adding a recommendation is a separate action from saving the count.
5. Save the count explicitly, then use History to check its saved snapshot.

- Grouping only changes the display. Your counts, units, notes and search stay in place when switching. Your browser remembers the choice for this user and location. Counts support three decimal places; only Save stock count records a shared count.

### Count sleeves or smaller packs

Convert a physical smaller-pack count into ordering units.

Route: `/admin#stock`

1. Open Ordering → Stock items, edit the item and choose Pack & counting.
2. Keep Unit amount as the ordered pack, such as “Box of 1,000 cups”. Set Count in smaller packs to Sleeves and 20 per ordered unit.
3. Save changes, then enter sleeves in Stock count. For example, 10 sleeves is 0.5 of that box.
4. Check the conversion shown beside the count before saving.

- Targets, prices, recommendations and supplier orders remain in ordered packs. A changed conversion must be reviewed before an older count draft is saved.

### Review count history and usage

Understand saved stock snapshots and completed usage cycles.

Route: `/stock-count#usage`

1. Open Stock count → History and View count. Choose Group by → Area or Supplier to review the saved quantities and units using their original names.
2. Open Weekly usage to inspect the Sunday–Saturday cycles and storage groups.
3. Compare opening count, orders and confirmed transfer effects with the following Sunday’s closing count.
4. Investigate missing counts or negative usage before relying on the automatic target.

- A stock count is a snapshot, so several counts are not added together as stock on hand. Missing quantities remain unknown.

### Choose target level calculations

Use item usage or a quantity per projected sales amount.

Route: `/admin/accounts#locations`

1. When adding a location, choose Target level system once. It applies to every current and future stock item at that location.
2. In location setup, open Target level system. Automatic usage (current) keeps the existing usage/manual fallback; Projected sales enables item ratios.
3. For Projected sales, enter the sales amount and item quantity in setup or Stock items → Ordering rules. $1,000 and 0.5 boxes gives 5 boxes for $10,000 projected sales.
4. Save and review the target in Ordering or Stock count. Change the shared system later in Edit location → General → Target level system.

- Each location chooses one system; item quantities remain separate because stock items use different amounts. Missing ratios or forecasts stay unavailable. Projected sales uses Ordering’s original weekly forecast, including holidays and Sunday’s next-week rollover, in place of delivery coverage. Order when and order rounding stay unchanged. Switching systems retains ratios. Older locations keep legacy item choices until a shared system is selected.

### Understand the automatic Order when level

Know when the system recommends replenishing stock.

1. Find Order when in the item’s Ordering details or Stock count row.
2. For weekly targets it is based on average weekly usage across the available completed cycles. The Projected sales method changes the target, while this usage trigger stays automatic.
3. Above that level, the recommendation is zero. At or below it, the system recommends enough to reach the target, subject to ordering rules.
4. Use your physical stock count and review the suggestion before adding it to the cart.

- For a target of 10 boxes with 10 in stock, no additional boxes are needed. With the Automatic usage method, delivery plans can replace the weekly trigger with delivery coverage. Order when is calculated automatically.

### Add or edit stock items

Keep item details, pack sizes and ordering rules together.

Route: `/admin#stock`

1. Open Ordering → Stock items. Choose Add new stock or the pencil beside an existing item.
2. Use Item details for name, supplier, price, supplier SKU, category and optional photo.
3. Use Pack & counting for unit amount, storage group and smaller-pack conversion.
4. Use Ordering rules for minimum quantities and rounding. The location’s target system is shown here; enter this item’s sales ratio when Projected sales is selected.
5. Press Save changes once for the whole popup. Correct any highlighted field if its tab opens.

- Close retains the current item’s draft for reopening; Cancel edit discards it. Remove stock is inside Item details → More actions. Company stock changes apply across that company.

### Set minimum quantities and rounding

Match recommendations and cart quantities to supplier pack rules.

Route: `/admin#stock`

1. Edit a stock item and open Ordering rules.
2. Set Minimum order quantity, then choose Minimum only, Multiples of minimum, Custom cutoff or Separate up/down cutoffs.
3. For multiples of 15, a requirement of 19 rounds to 30. For a custom cutoff of 5, 19 rounds to 15 and 20 rounds to 30.
4. Save changes and review any cart notice about updated quantity rules.

- Rules apply to positive ordered quantities and use ordered units/packs. Saved historical quantities remain as recorded. The live cart limit is 999 per item.

### Add suppliers and order recipients

Configure the supplier side of order delivery.

Route: `/admin#suppliers`

1. Open Ordering → Suppliers & delivery and add or edit a supplier.
2. In Order delivery, select the sending method and save the correct email recipient or other required contact details.
3. Assign stock items to the supplier in their item settings.
4. Configure each location’s separate Sending settings and delivery schedule.

- Supplier contacts belong to the company catalogue. Sender email and API key belong to the location. Both sides must be configured for email sending.

### Understand stock price updates

See how a price change affects recent order values.

1. Change an item’s price in Stock items, or confirm reviewed price updates from an invoice.
2. The effective price also updates the latest non-deleted order containing that item at each compatible location in the company.
3. Open Order history to see Stock prices updated, the original prices and the revised total.
4. Review ordering budgets and order reports using the revised values.

- Previously sent emails retain their original estimates. Weekly financial Cost of goods uses saved invoices rather than these order totals.

### Record and review stock wastage

Track wasted stock items and their estimated cost at the selected location.

Route: `/wastage`

1. Open Ordering → Wastage and check the selected location. Choose Record wastage to open the entry popup.
2. Choose the wastage date, stock items and a reason for each item. Enter quantities in ordered packs, or select the item’s saved counting unit such as sleeves. Review the pack conversion and estimated cost.
3. Add any notes and press Save wastage. Only saving records the entry. A closed draft can be reopened; an uncertain save must be retried to check the same entry safely.
4. Use Today, This week, Last week, This month or custom dates, then search or filter by reason. Review waste by reason, the highest item costs and the log; Export CSV downloads all matching entries.
5. Open View entry to see its original units, price and staff attribution. If it was a mistake, use Void entry, enter a reason and confirm. Voided entries remain in the log but are excluded from totals.

- Wastage uses saved stock cost prices, not selling prices. Missing prices stay pending; known subtotals are labelled. Later stock-price or pack changes do not rewrite saved entries.
- Stock counts remain physical snapshots. Wastage is logged separately, so it does not subtract stock a second time, change target calculations or add another expense to invoice-based Cost of goods.
- Viewing, recording, voiding and CSV exports have separate permission controls under stock counts. Choose the appropriate location to review its records. Finished meals are not included in this version.

### Transfer stock between locations

Record a transfer and confirm its arrival.

Route: `/stock-transfers`

1. Open Ordering → Stock transfers and create a transfer for an accessible destination.
2. Choose items, check the receiving units and quantities, and review any cost movement before submitting.
3. The receiving location reviews the pending transfer and explicitly confirms receipt.
4. Use transfer history to check its status. Pending transfers do not move stock until confirmed.

- Cross-company transfers require compatible item mapping and the appropriate access. Review snapshots carefully; receiving applies the saved movement.

### Approve incoming transfers from Home

Show receipt approvals to assigned location managers.

Route: `/home`

1. Assign the receiving manager under Edit location → Managers.
2. Give that account Home, View stock transfers and Receive stock transfers permissions.
3. With the receiving location selected, open Home and choose Review transfer in the pending panel.
4. Check every item and choose Approve receipt only when the stock has arrived.

- Manager dashboard choice alone does not qualify. Only the first five pending transfers appear on Home; All transfers opens the full list.

## Supplier deliveries

### Set supplier delivery days for a location

Give each store its own regular and one-off supplier schedule.

Route: `/admin/accounts#locations`

1. Open Admin → Locations → Edit location → Supplier delivery days.
2. Find the supplier and select its regular Monday–Sunday delivery days.
3. Expand Delivery timing & exceptions to add lead time, cutoff, arrival time or one-off changes.
4. Press the location popup’s Save settings. Review the resulting estimates in Ordering and the cart.

- Schedules are independent for each location. Fill all three timing fields to enable delivery-based recommendations.

### Set lead time and order cutoffs

Estimate the next delivery still available to order.

Route: `/admin/accounts#locations`

1. Expand a supplier’s Delivery timing & exceptions in location settings.
2. Set lead time in calendar days, Order cutoff and expected Delivery time. Same-day cutoffs must be earlier than arrival.
3. For Tuesday/Friday delivery with one day’s lead time and a 2 pm cutoff, order before Monday 2 pm for Tuesday. After that, Friday is the next eligible estimate.
4. Save settings and check Order by and Estimated delivery in the cart and review.

- Timing follows the location state’s capital-city timezone, with Melbourne used when no state is set. Cutoffs are planning guidance; placing an order remains an explicit action.

### Understand delivery-based recommended quantities

Cover expected usage until the delivery after your next delivery.

1. Set regular delivery days and complete lead time, cutoff and arrival time for the supplier.
2. The app estimates usage from now until the following arrival using completed item usage and available sales forecast patterns.
3. Estimated available stock and eligible confirmed incoming quantities reduce the recommendation. For 10 needed, 3 available and 2 incoming, the starting recommendation is 5.
4. In Stock count, enter the physical quantity to calculate the recommendation against that count. Check shortage and overdue warnings before adding it.

- Incoming stock must arrive before the end of the coverage period. Unknown or overdue deliveries need review. Ordering’s available-stock estimate needs a saved count no more than 28 days old; a fresh physical count is preferable. For the Automatic usage method, missing sales uses average weekly usage spread across days and missing item usage retains the normal/manual fallback. Projected sales uses its selected weekly target instead of delivery coverage.

### Understand shortage and overdue warnings

Check whether stock can last until the next arrival.

1. Read May run out before delivery beneath an item in Ordering or beside its Stock count details.
2. Check the most recent count and any received stock, then verify pending orders and their arrival dates.
3. Use Order history to confirm an externally placed order, correct its delivery date or record its receipt.
4. If stock is genuinely insufficient, arrange the appropriate supplier action and place an order explicitly.

- Overdue and unconfirmed orders are flagged separately instead of being treated as assured incoming stock. A recommendation cannot make a supplier deliver earlier.

### Confirm orders and mark deliveries received

Track each supplier’s outstanding and received goods.

Route: `/order-history`

1. Open Order history → View order → Delivery tracking.
2. Use Confirm ordered for stock actually ordered externally or not confirmed by the sending service, and enter its expected date.
3. Use Change delivery date to correct an outstanding estimate.
4. When every item from that supplier arrives, choose Mark received, check the items and press Confirm received.

- Suppliers in one order can be received separately; each confirmation covers that supplier’s full delivery. Receipts enter estimated stock once, and later counts prevent double credit. Older historical receipts update history only unless an outstanding future order was explicitly included in planning. These actions do not resend supplier emails.

### Skip holidays or change a delivery date

Handle public holidays, cancelled days and extra deliveries.

Route: `/admin/accounts#locations`

1. Set the location’s state, then open Supplier delivery days → Delivery timing & exceptions.
2. Turn on Skip public holidays when the supplier does not deliver on the location’s holidays.
3. Add a dated exception and choose to skip that delivery or allow an extra delivery.
4. Save settings and review the next eligible delivery. For an already placed order, correct its expected date separately in Order history.

- Dated exceptions override regular weekdays and holiday skips. A holiday calendar is required for holiday skipping; reviewed location calendars take priority.

## Sales & projections

### Enter daily sales from Home or Sales

Save a daily total and find it again in history.

Route: `/sales#entry`

1. Check the location and trading date shown in Home’s Daily sales reminder, or open Sales → Daily sales and select the week.
2. Enter the daily total. Use 0 for a recorded zero-sales day and leave unknown days blank.
3. Press Save sales and wait for confirmation.
4. Use Daily sales history to open the matching week and verify the saved amount.

- The Home reminder is available on Store dashboards only. Head Office users enter daily totals through Sales → Daily sales. Daily sales and Weekly report are separate inputs. A complete Weekly report revenue breakdown takes priority for forecasting without overwriting the Daily sales entry.

### Enter sales for stores closing after midnight

Keep late-night sales attached to the correct trading day.

Route: `/home`

1. Save accurate opening and closing times for every trading day in location settings.
2. Check Home’s displayed trading date before entering sales after midnight.
3. An overnight period stays associated with the day it opened until its saved closing time.
4. Use Home’s Daily sales history link to open that trading week, including Sunday-night entries saved early Monday.

- Closing exactly at midnight completes that trading period. A closing time earlier than opening is the following day; equal times represent 24 hours.

### Complete a weekly sales report

Reconcile sales channels and save the week’s financial entries.

Route: `/sales#report`

1. Open Sales → Weekly report and select the location and Monday–Sunday week.
2. Enter Till sales, Cash, Eftpos, Petty cash, Uber Eats and DoorDash. Arrow keys and Enter move between entry fields.
3. Record actual zeroes for unused channels; leave unknown amounts blank.
4. Review the expense views and platform fee tables, then press Save weekly report.
5. Use Overview to compare saved weekly sales, cost percentages and profit.

- Report sales = Till + Uber Eats + DoorDash. Cash variance = Cash + Eftpos + Petty cash − Till. Platform fees are shown separately from profit. Invoice totals supply Cost of goods.

### Upload a weekly sales report

Review an Excel, PDF or photo report before importing its sales and platform fees.

Route: `/sales#report`

1. Open Sales → Weekly report and choose Upload sales report. Select the location the report belongs to.
2. Choose an Excel (.xlsx), PDF, JPEG/JPG, PNG or WebP report up to 5 MB. Excel opens its preview directly. For a scan, select up to three PDF pages and check the text and images to send.
3. For a PDF or photo, choose Read report · OpStack intelligence. Check and edit the extracted Monday–Sunday dates, sales channels, printed totals and weekly platform fees. Reading does not save sales.
4. For a scan, check the report location, tick the location confirmation and choose Review import. Review the dated weeks and totals, then choose Import weeks to save.
5. Check the imported week. Matching values are retained, missing values filled, and a whole week with conflicting saved figures is skipped.

- PDFs and photos require enabled company OpStack intelligence and use its request limit and budget. Excel does not use intelligence. Only reviewed sales and platform fees are imported; Daily sales, labour, operating expenses, R&O and invoices remain separate. Blank fields stay unrecorded; enter zero only when known. Recalculate and save Excel formulas before uploading if their saved values are missing.

### Understand daily and weekly projected sales

See which saved sales determine the forecast.

Route: `/sales#projection`

1. Open Sales → Projection & budget to view the source weeks and any missing-history explanation.
2. Normal forecasts average corresponding weekdays from four completed weeks; public holidays are replaced by earlier normal weekdays.
3. For each past day, a complete Weekly report Till + Uber Eats + DoorDash total takes priority; otherwise the saved Daily sales amount is used.
4. Correct missing historical sales and save. Forecasts refresh from the saved inputs.

- At midnight Sunday in Melbourne, Home, Ordering and Sales weekly forecasts switch to the upcoming Monday–Sunday week. Actual current-week comparisons retain their dates. Holidays can use the prior-year method instead.

### Set automatic public holidays

Use the right Australian holiday calendar at each location.

Route: `/admin/accounts#locations`

1. Open Admin → Locations → Edit location → General.
2. Choose State or territory and press Save settings.
3. Look for a solid blue star on holiday dates in Home, Daily sales, Weekly report and Rostering.
4. For regional or special exceptions, an authorised manager can review the location calendar in Settings → Award compliance → Public holidays.

- State holidays fill automatically, including Easter and substitute dates. Reviewed calendars override automatic dates for that year. Roster estimates use state holidays automatically; actual pay approval still requires a reviewed calendar.

### Understand holiday forecasts and yearly growth

Adjust the same named holiday’s prior-year sales for growth.

1. Choose the location’s state and ensure its historical sales are complete.
2. For a holiday, the app looks for the same uniquely named holiday in the previous year, even when its date moves.
3. It adjusts that day’s revenue by comparable total sales growth or decline since the previous holiday, excluding holiday dates on both sides.
4. Review the holiday, previous date, growth percentage or fallback explanation in the projection.

- Last year’s $2,000 holiday becomes $2,400 when the comparable sales increase is 20%. Missing or ambiguous history keeps the normal forecast with an explanation. Normal days keep the four-week method.

### Scan and submit hourly sales reports

Import reviewed hourly amounts from spreadsheets, PDFs or images.

Route: `/sales#hourly`

1. Open Sales → Hourly sales → OpStack intelligence · Upload report, or Scan hourly sales report on Manager Home.
2. Choose a CSV/XLSX report, PDF or supported image. Review its source text and selected pages, then press Read report.
3. Check dates, location, printed time intervals, hourly amounts and totals. Select Trading day or Calendar day if requested.
4. Only select the full-day option when unlisted hours truly mean $0. Use Replace differing saved hours only for an intended correction.
5. Press Submit hourly sales in the popup footer. Wait for confirmation, then view the imported date.

- 11:01–12:00 means sales in the hour starting at 11, not the hour starting at 12. Times display in AM/PM. Calendar-day conversion needs all seven trading-hour entries. Scanning alone does not save hourly sales or the Daily sales total.

### Understand hourly sales projections

Distribute the daily forecast using complete hourly history.

Route: `/sales#hourly`

1. Open Sales → Hourly sales, select a trading date and compare the chart and hourly table.
2. Normal days use complete hourly profiles from the same four normal weekdays as the daily forecast, replacing public holidays with earlier normal days.
3. A matching prior holiday can supply its own hourly profile for a holiday forecast.
4. Open Rostering’s Hourly sales projections panel to use the same forecast while planning staff.

- Projected hours add up to the shared daily forecast. Missing profiles show an explanation. After-midnight hours are marked +1 day and remain with the opening trading date. Forecast calculations do not make intelligence requests.

### Understand the weekly ordering budget

Compare forecast-based spending allowance with orders and cart.

Route: `/sales#projection`

1. View Projection & budget, Ordering or the cart.
2. The ordering budget is projected weekly sales × 28%.
3. In Ordering, review Available after cart and the budget-used bar, including saved order costs, net stock-cost transfers and this cart. Review cart opens the existing cart.
4. Compare both COGS estimates: Original projection uses the original forecast; Updated projection adds or subtracts how much saved sales are above or below forecast so far. Each is green within budget and red over.

- Both COGS estimates use allocated saved-order costs, including net cost transfers, plus the current cart where available. Original projection divides those costs by original projected sales; Updated projection divides them by the original weekly sales forecast plus the dollar variance so far. Each is shown as a percentage with its own budget colour. Weekly financial COGS uses saved invoices. The original forecast, 28% budget and budget-used bar keep their planning basis.
- Expected sales uses complete Weekly report Till + Uber Eats + DoorDash for each recorded day, otherwise Daily sales. Subtract the holiday-adjusted forecast for those same days from actual sales. A $7,000 original week plus $400 above forecast becomes $7,400; $400 below becomes $6,600. Unrecorded days keep their original forecasts. Missing past sales remain estimated. Partial hourly reports and future-entered totals are excluded.
- With no comparable sales, COGS uses the baseline forecast. Missing or zero expected sales and pending prices show a neutral dash. COGS is green at or below the budget percentage and red above it, using unrounded amounts.
- On Sunday, the displayed forecast and budget move to the upcoming week. Its updated projection starts from its own forecast, without carrying the previous week’s dollar variance.
- Ordering shows Near budget at 90% used and Over budget when the cart exceeds the remaining amount. The exact percentage can exceed 100%, while the bar stops at full. Retry budget reloads figures after a connection problem.
- Saved orders count even if supplier sending failed. Pending prices keep the remaining budget unknown. Budget warnings are guidance and do not block an explicit order.

### Record Uber Eats and DoorDash fees

Check platform deductions and expected payouts separately.

Route: `/sales#report`

1. Open the selected week in Weekly report.
2. Choose the Uber Eats or DoorDash overview card.
3. Enter Fees, Marketing and Refunds, preserving genuine credit adjustments and using 0 for unused known fees.
4. Review Total fees and Expected pay, then Save weekly report.

- Total fees = Fees + Marketing + Refunds. Expected pay = platform sales − Total fees. These figures stay separate from the app’s profit calculation.

## Invoices & expenses

### Scan, review and save an invoice

Store an invoice and its GST-inclusive total in a weekly bundle.

Route: `/home`

1. Open Home’s Invoice scanner and choose Take photo or Upload invoice. PDF, JPEG, PNG and WebP uploads automatically use OpStack intelligence when it is enabled and permitted.
2. Expand Invoice details and check the supplier. Use Choose supplier to search your company’s saved suppliers and correct a wrong scan, or edit the name directly. Check the invoice number, date, subtotal, GST and total against the original.
3. Check the bundle week, which can be changed independently of the invoice date.
4. Review any proposed stock price changes, then choose Save invoice or Confirm price updates.
5. Open Weekly bundles, expand the saved week and choose Download bundle for one ZIP of its original images and PDFs. Open an individual invoice to correct details, move it, download its original or delete it with confirmation.

- Automatic intelligence uses the company allowance. Local reading remains available if intelligence is disabled, unavailable or not permitted. A unique detected supplier name is matched to the company’s saved supplier; ambiguous names stay editable. Check printed GST rather than assuming every item is taxable. Saving an invoice contributes its total to weekly costs; a missing total leaves the financial result incomplete.
- Files inside a downloaded bundle include each invoice’s saved supplier name. Missing names use Unknown supplier.

### Confirm stock prices detected on invoices

Apply reviewed price differences to existing company items.

1. Scan or upload an invoice and check its invoice date and transcription.
2. Review Price updates. Matching uses a unique SKU first, then a unique item name, and shows differing current → new prices.
3. If the supplier is wrong, expand Invoice details → Choose supplier and select the correct company supplier. Review the refreshed price comparison, then press Confirm price updates to save and apply it.
4. If another user changed a price or pack, review the refreshed comparison before confirming again.

- Applying prices requires invoice-editing and stock-management permission. Unknown items, ambiguous matches and unclear pack/tax conversions are skipped. Older invoices cannot replace newer invoice prices.

### Understand weekly Cost of goods

Use saved invoices as the week’s expense source.

Route: `/sales#expense-stock`

1. Save each invoice in the correct location’s Monday–Sunday bundle.
2. Open Sales → Weekly report → Cost of goods to review the saved invoice totals and eligible cost transfers.
3. Correct an invoice total or bundle week in the invoice itself; the financial view recalculates from the saved document.
4. Check that all invoices have known totals before relying on profit.

- No saved invoices means $0 in invoice expense. Missing totals keep costs incomplete. Orders and invoices are not added together as duplicate expenses.

### Enter Labour and R&O expenses

Record weekly cost lines and distinguish zero from missing.

Route: `/sales#expense-labour`

1. Open the correct week in Sales → Weekly report.
2. Choose Labour to enter named hours × hourly rate lines, or R&O to enter named quantity × unit cost lines.
3. Add, edit or remove the relevant entries. Use Record no cost when the category is a confirmed zero.
4. Review the calculated totals and press Save weekly report.

- Weekly financial labour entries are separate from roster planning and timesheet approval. Unknown costs keep full profit incomplete.

### Schedule operating expense bills

Spread a saved bill across the correct weeks exactly once.

Route: `/sales#expense-operating-expenses`

1. Open Weekly report → Op Ex and choose or add an expense type.
2. Enter the bill’s total cost, Monday start week and number of covered weeks.
3. Choose Save expense to save it across those weeks, or Save weekly report to save pending bills with the report.
4. Use Saved bills to edit or delete an existing bill. Add a separate bill when the previous coverage ends.

- A $100 bill over two weeks contributes $50 to each, then stops. Same-type overlapping bills are rejected. Rounding distributes cents so allocations equal the original total.

## Rosters & time

### View your roster or the team roster

Find published shifts for your location and week.

Route: `/rostering#roster`

1. Open Rostering and choose the week using arrows or the calendar.
2. On a phone, use My roster for your shifts and Team roster for a day’s published team schedule.
3. Check overnight labels and shifts continuing from the previous night.
4. Close the phone popup to return to the app; Open roster reopens it.

- Ordinary staff views show published work. Manager edits remain drafts until published. Roster makers open shift costs through each card’s dollar icon and see weekly staff totals. The cost popup shows missing details when a shift cannot be priced.

### Build and edit a roster

Plan draft shifts using Staff, Stacked or Day view.

Route: `/rostering#roster`

1. Open the roster maker with roster-management access. Select the week using the arrows, This week or the calendar. The outlook below the controls shows projected sales, labour budget, roster cost and budget remaining when permitted.
2. Use the Staff, Stacked and Day buttons to choose a view. Press + inside a day/staff cell, then set the time, person and position in its compact shift card. At locations with the current automatic award setup, new and edited shifts receive planned breaks automatically. Today is highlighted in the week grid.
3. Drag the blank part of a shift card to move it; a mouse can also drag its staff name or position. On a tablet, use the blank bottom area. Drag a Day-view bar to change staff or time. The highlighted row/day shows the destination; Escape cancels. Check overlap or availability warnings.
4. Review autosave status. Open a card’s dollar icon for its tabbed shift popup. The shift popup groups Details, Breaks, Costs, Notes, Warnings and Status; Save shift applies popup edits to the draft. Expand Itemised calculation for pay lines. Staff view retains weekly totals. A soft red tint and thin border take priority for availability, configured shift-length/rest, planned-break or save issues: hover over the card’s top to read them, or click the red icon. Keyboard focus also shows the issues; Escape dismisses them.
5. Use Copy week on an empty week to review a copy of the previous week. Check the Draft, Unpublished changes or Published status, then publish separately when ready. A soft green tint and thin border mark shifts matching their published version; editing one removes its green until republished. Red issue borders take priority and do not mean every issue blocks publication.

- Autosaving does not publish. Vacant shifts have unknown costs until assigned and priced.

### Automatic annual leave and super

Track leave from confirmed hours and see separate roster cost estimates.

Route: `/rostering#leave`

1. Open Rostering → Leave. Your annual leave card shows the tracked balance, available hours after booked leave, accrual and reserved hours. Authorised reviewers can select a staff member. Casual employees do not earn paid annual leave.
2. Use Set starting balance once for existing staff. Enter the confirmed payroll hours at the start of the selected date. Normal paid hours can prefill all-day leave; keep unknown days blank and exclude breaks and overtime. Save explicitly. Earlier history is covered by this starting amount. A future starting date activates tracking when it arrives.
3. Approve timesheets to accrue one hour of annual leave for every thirteen eligible ordinary hours. Approved paid absences also accrue leave when their confirmed dates finish. On leave approval, review the ordinary paid hours, excluding public holidays from annual leave. Unconfirmed hours make the balance incomplete; Paid leave hours confirms them later. Cancelling approved leave releases its reservation.
4. Open a shift’s dollar icon → Costs for super, annual leave provision and employer estimate. Super defaults to 12% of eligible ordinary-time earnings. Under-18 staff qualify when recorded employer work exceeds thirty hours in the week. Existing explicit overrides remain available. Annual leave provision includes estimated loading; ordinary gross wages and budget calculations stay separate.

- Leave tracking needs a known starting balance and complete approved ordinary-hour records. Missing legacy data stays unavailable instead of becoming zero. Employer locations keep separate balances; legacy shared employers combine their own records. Paid absence hours record leave tracking, not leave pay. Super and leave provisions are uncapped planning estimates; fund payments, payroll caps, cashing out and actual leave pay are separate. Approved pay and earlier reviews remain frozen. Special minimum payments, mixed overtime allowances and unsupported arrangements can require further ordinary-hours evidence.

### Review and edit a shift

Use the company-styled shift popup without losing your roster draft.

Route: `/rostering#roster`

1. Open a saved shift’s dollar icon for Costs, then select Details. The header shows the employee, date, paid duration, position and saved publication status. In Details, change the date within this week, staff member, 12-hour times or position.
2. Choose Breaks to review the automatic paid rest and unpaid meal timetable. Plans update when shift times change and respect recorded part-time meals. Custom timing must pass the award checks. Save shift applies popup edits; actual breaks are clocked separately.
3. Choose Costs to see gross wages and allowances, separate super, annual leave provision, employer and on-cost estimates, and Itemised calculation. Missing costs stay unavailable with their blocking reasons. Saved estimates are labelled while you edit; Save shift recalculates them.
4. Use Notes for shift instructions. All popup fields keep their draft when switching tabs. Save shift applies the changes together to the roster draft. Cancel, Escape and the close button ask before discarding unsaved changes.
5. Choose Warnings to see the saved shift’s scheduling issues, including availability and configured shift/rest limits. Pay and award reviews are kept out of roster building. Missing wage setup is explained in Costs. Warnings update after saving.
6. Choose Status for this shift’s Draft, Published or Unpublished changes status. Copy shift and Duplicate open a review before creating one draft copy. Delete shift keeps native Undo. Leave opens existing leave tools. Publish week explicitly publishes all saved shifts without an award review or review note.

- Opening or changing tabs never saves, copies, publishes or requests leave. Copies do not transfer recorded allowance facts or written variations. A copied employee shift must pass overlap and availability checks. After an uncertain copy, reload and check the roster before creating another. On phones, new shift editing stays unavailable; resizing an open editor retains drafts for a computer.

### Plan award breaks automatically

Save paid rest and unpaid meal times with the roster while keeping actual work separate.

Route: `/rostering#roster`

1. Complete the location’s current Fast Food Award setup. New and edited shifts automatically receive a break plan when saved; inline card edits use the normal autosave. Existing published rosters and approved timesheets are preserved.
2. Open the shift’s dollar icon and choose Breaks. Automatic shows the planned paid 10-minute rests and unpaid meals with 12-hour times. The standard meal is 30 minutes; counts and timing follow working hours, five-hour limits and recorded part-time meals.
3. Change the shift start or finish in Details, then review the updated Breaks preview. Paid rests remain paid. Shorter shifts remove unneeded meals; longer shifts add the required breaks. Save shift applies popup changes and recalculates the roster estimate.
4. For a permitted adjustment, choose Custom and edit the planned times or durations. Owed breaks, first/last-hour limits, separate rest and meal breaks, and part-time agreement times are checked before saving. Record an agreed written variation when changing an agreed meal.
5. Review any planning issue before saving or publishing. A recorded meal that cannot fit the shift needs an agreement review. Adjacent cards forming one continuous engagement must be combined for automatic planning. Unresolved plans never claim a complete wage estimate.
6. Publish the reviewed week. Staff can expand Planned breaks on their published roster, including on phones. Staff must still clock actual breaks when taken: plans do not create clock events or automatically deduct unpaid time from actual work.

- Automatic planning uses the included award edition and supports standard continuous shifts up to sixteen hours. It preserves explicit custom plans and recorded part-time meal times; an hours-only IFA does not waive breaks. Custom plans and longer/unsupported arrangements require the current checks and review. Planning readiness is not a certificate of complete employment-law compliance. Opening a preview never writes a shift, agreement, timesheet or approval.

### Publish a roster

Make saved draft shifts visible to staff.

Route: `/rostering#roster`

1. Check people, times, positions, breaks and the selected week.
2. Resolve invalid or overlapping shifts and review availability, leave and cost warnings. A soft red tint and thin border take priority even on a previously published shift. Hover over the card’s top, focus the card, or click its red error icon to read the relevant issues.
3. Wait for draft saves to finish, then choose Publish roster. A soft green tint and thin border mark unchanged published shifts when they have no current issues. A green border indicates publication, not legal compliance.
4. Publishing needs no award review or review note. Staff see the saved published shifts; later draft edits remain private until the next publication. Automatic-break and scheduling validation still apply.

- Previously published schedules stay visible to staff until the next publication. A copied or autosaved draft is not yet published.

### Use hourly sales and labour forecasts on rosters

Compare demand and budget while planning shifts.

Route: `/rostering#roster`

1. Open the roster’s sales and budget summary with the required financial summary access.
2. Choose Day view and select the roster date. Projected sales appear directly beneath each hour of the timeline.
3. Compare the amounts beneath the hours with planned staffing and the day’s budget. Home and Sales → Hourly sales keep their own forecast views.
4. After-midnight hours use the previous trading day when that location traded overnight. A dash means the forecast is unavailable; hover over the hour for its date or missing-data reason.

- These are the same forecasts as Hourly sales. Viewing them does not import sales or change shifts. Staff without summary access keep the ordinary published-roster view.

### Start and finish a shift

Record your actual work using your unique staff PIN.

Route: `/rostering#roster`

1. Open the blue Shift clock and enter the last four digits of your saved phone number.
2. Choose Start shift when your assigned published shift is available.
3. For each later action, enter your PIN again and choose the offered break or Clock out action.
4. After clock-out, review your pending timesheet. Submit missing or unrostered work as a manual timesheet with a reason.

- Unlocking the keypad alone records nothing. A phone number is required and its four-digit ending must be unique across the network.

### Request an early start

Ask an authorised manager to approve an earlier clock-in.

1. On the scheduled Melbourne day, enter your own PIN and select Start shift before the scheduled start.
2. Ask a different authorised manager to enter their PIN in Manager approval.
3. Complete the action and check that the actual start was recorded.

- The approver needs Review timesheets access for the location. Early-start approval records who approved it and does not replace overtime or award calculations.

### Record rest and meal breaks

Track actual break starts and finishes.

1. Enter your PIN in Shift clock while working and choose an available required break.
2. Return to the clock, enter your PIN again and choose End break when it finishes.
3. Review prompts for additional breaks if the shift runs longer.
4. Record a required reason for a break timing exception when prompted.

- Paid rest breaks remain paid. Actual unpaid meal duration is recorded. Managers remain responsible for arranging appropriate breaks.

### Submit, correct and approve timesheets

Review rostered shifts, actual work, break evidence and wage differences.

Route: `/rostering#timesheets`

1. Open Rostering → Timesheets and choose the location and week. Published shifts appear as Rostered cards before clock-in. These are plans, not worked time: they do not add actual wages, approved hours, leave accrual or CSV work rows. Filter Rostered shifts to see them separately.
2. Review actual clock-in/out, paid hours and the matched roster. Authorised wage viewers also see the published roster cost, worked wage cost and dollar variance, plus hours variance. Positive dollar variance means a higher worked cost; negative means lower. Unknown or ambiguous matches stay unavailable. A uniquely linked work record replaces its Rostered card.
3. Use the separate Breaks button to add, edit or remove actual paid rests and unpaid meals after clock-out. Enter the real start and finish, review the live award preview, enter a reason and explicitly Save breaks. Paid rests remain paid. Existing untimed unpaid totals need explicit replacement confirmation. Saving reopens approved work; original clock events and before/after evidence remain in History. Rostered cards show planned breaks only.
4. Use Correct for actual start/finish changes, or Add worked times on a completed Rostered card if clocking was missed; confirm the actual times and a reason. Approval runs fresh pay and award checks, including required employment and reviewed holiday calendars. Exceptions stay visible and review notes do not waive entitlements or certify legal compliance. Pay details keeps actual allowances and reimbursements. Export CSV includes recorded work only.

- Comparisons use gross wages and allowances, not super or leave provisions. New clock-ins retain the roster cost saved at clock-in; manual comparisons use the uniquely matched published estimate, never unpublished drafts. Costs stay unknown when reliable evidence is missing. Recording a break exception does not make it compliant, and a cost variance never changes pay automatically. Employee records and accessible backups must be retained for at least seven years. Award coverage, classification, current rules and other applicable laws still require employer review.

### Manage availability and leave

Keep scheduling informed by when people can work.

Route: `/rostering#availability`

1. Open Rostering → Availability to enter your recurring availability and dated changes.
2. Open Leave to request time away and review its status.
3. Authorised managers review requests and consider availability warnings when editing shifts.
4. Check the published roster after changes rather than assuming an availability entry edits an existing shift.

### Set labour budgets, rates and positions

Configure the values used for roster planning.

Route: `/rostering#settings`

1. Open Rostering → Labour settings with the appropriate management permission.
2. Choose the authorised network, company or location budget scope and save the planned budget settings.
3. For automatic award rates, use Award compliance → Overview → Employee details or the user’s Employment & award editor. Legacy flat rates remain available where automatic wages are off.
4. Use Positions to add or rename company positions and choose their shift-card colours, then Save positions.

- Budget permissions differ by scope. Positions and colours are shared across the selected company’s locations. Employment and award terms are managed separately in Users.

## Checklists & planners

### Complete an active checklist

Record responses and finish the work currently planned for you.

Route: `/ops-management#checklists`

1. Open Checklists and select an active card for the current location and planned day.
2. Enter the required responses, photos or other evidence and wait for saves to finish.
3. For a checklist with one checkbox response, use the card’s tick to complete it directly.
4. When all required responses are saved and uploads finish, completion is recorded. Review History for completed or earlier work.

- Active cards only appear during their planned window and leave the list when it ends. History retains saved work. Opening a card alone does not complete it.

### Build a checklist

Create instructions and response steps before planning its use.

Route: `/ops-management#templates`

1. Open Checklists → Checklist builder and create or edit a checklist.
2. Add sections, instructions and response steps. Choose the response type and set required fields or validation.
3. Reorder sections with their following steps, or move individual steps as needed.
4. Wait for valid edits to save, then open Planner to choose timing, locations and assignees.

- Content editing and planners have their own saved settings. A draft or paused planner does not create active work.

### Choose checklist responses and timed sections

Collect the right evidence for each task.

Route: `/ops-management#templates`

1. Select a step in Checklist builder and choose a native response type, such as checkbox, text, number, selection, photo or signature.
2. Set required status, options or numeric precision where available.
3. Use instructions or section headings to explain the task; these are not responses.
4. Configure timed sections when a minimum elapsed process is needed, then review the complete checklist before planning it.

- Step activity and completion are recorded from saved work. Required uploads and active editing must finish before completion.

### Configure checklist Plans

Use one planner for each checklist.

Route: `/ops-management#templates`

1. Open the checklist’s Plans stage. Choose Set up planner if none exists, or Edit planner to change its single planner.
2. Choose recurrence, a start date and fixed times or location trading hours. Plan breakdown shows repeats, active hours and deadlines. Expand Current and next runs for exact windows. Planners continue until paused; once off still runs once.
3. Use Locations and Assignees to choose who should receive that planner’s work.
4. Review the saved planner and activate it when ready. Older checklists with several planners must use Keep this planner to choose one; the others stop creating work while saved records remain in History.

- One planner holds the checklist’s recurrence, locations and audience. End-date fields are removed. Existing saved limits clear only on an explicit settings edit. Review paused intelligence-generated plans before activation.

### Repeat checklists hourly or around trading hours

Make planned tasks follow each location’s opening and closing.

Route: `/ops-management#templates`

1. In Plans, choose Hourly recurrence for a separate checklist occurrence each hour within the window.
2. Choose Location trading hours to base the window on saved opening/closing times, adding offsets when needed.
3. Check the assigned locations have valid hours. Expand the Plan breakdown’s next runs to review each hourly window and its finish, including overnight times.
4. Activate the planner. Active work appears only when its planned window is open.

- Closed days are skipped; missing hours require correction. Overnight work follows its opening trading day. Existing runs retain their frozen timing when hours change.

### Choose checklist locations and assignees

Target planned work to the right team.

Route: `/ops-management#templates`

1. Open a planner’s Locations group and select accessible locations.
2. Open Assignees and choose any permission-level or individual-user filters.
3. Review the combined audience and save the planner.
4. Check active work with the intended location and account context.

- Planner audiences also apply to managers and checklist reporting. Authoring requires authority over the affected locations.

### Review checklist history and progress

Find saved responses, completion and overdue work.

Route: `/ops-management#history`

1. Open Checklists → History and filter the saved records you can access.
2. Open a record to review progress and completion attribution.
3. Use Reporting → Checklists for filtered progress, overdue totals and location comparisons when permitted.
4. Check work dates and planner audiences when comparing locations.

- Reports can show today’s eligible unstarted tasks. Earlier unstarted schedules cannot be reconstructed from the current planner settings.

## Training

### Schedule and sign off in-store training

Plan practical training and record each staff member’s demonstrated skills.

Route: `/learning-centre#in-store`

1. Open Learning centre → In-store training. Use the location, search and status filters to find your sessions.
2. With training assignment access, choose New session. Set the location, trainer, date, Melbourne start time, duration, staff and practical skills, then press Create session.
3. Open View session and choose a staff member. The appointed trainer or an authorised manager ticks only the skills demonstrated competently, adds any notes and presses Save assessment.
4. Save partial progress until every skill is signed off. The final save records completion, the assessor and the time. Find these read-only records using the Completed filter.

- Self sign-off is excluded. Sign off in-store training is a separate detailed permission; managers also need training assignment access to assess sessions where they are not the appointed trainer. Assessments cannot be saved before the session starts. Cancelling a session retains saved completion records. Course progress reports continue to report online courses; practical progress is shown in In-store training.

### Start and complete a training course

Work through lessons and submit your knowledge check.

Route: `/learning-centre#my-learning`

1. Open Learning centre → My learning for assigned work, or Course library to start an available published course.
2. Open the course and complete its sections in order. Start timed reading where required.
3. Use each section’s transition to save answers and continue.
4. Submit the final knowledge check. Review a failed result and retry if needed.

- Courses open as a desktop popup or fullscreen on smaller devices. Closing with unsent answers asks before discarding them. A published assignment keeps its original course version.

### Build and preview a training course

Create lessons and questions with a live learner preview.

Route: `/learning-centre#builder`

1. Open Learning centre → Course builder and create or edit a draft.
2. Add sections and blocks from the outline or canvas insertion controls. Edit their properties in the left panel.
3. Write lessons, insert supported media or select a Knowledge Library article, and configure section formatting, transitions and reading time.
4. Use Test course to walk through the learner flow without recording training.
5. Check autosave, then publish a reviewed version separately.

- Refreshing Library content explicitly updates a draft; later article edits do not rewrite assigned course content.

### Use all training question types

Configure answers, marking and answer shuffling.

Route: `/learning-centre#builder`

1. In Course builder, add a Knowledge check block.
2. Choose Multiple choice, Multiple answers, True / false, Dropdown, Short answer, Fill in the blanks, Number, Matching or Put in order.
3. Set the answer key and points. Review accepted text variants, numeric tolerance, matching pairs or sequence where relevant.
4. Choose the course pass mark and optional Shuffle answer choices, then test and publish.

- Answer keys are marked on the server. Shuffling stays stable for a learner’s assignment; existing published assignments retain their settings.

### Publish, assign or archive training

Give staff a fixed, reviewed course version.

Route: `/learning-centre#courses`

1. Publish the reviewed draft in Course builder.
2. Use Planner in the builder or Assign on the course in Course library.
3. Select locations, any permission-level and staff filters, a due date and required/optional status.
4. Press Assign course explicitly. Review or cancel existing assignments in the same popup.
5. Archive a course when it should leave the library while retaining existing learning results.

- Filters combine, and newly added staff who match an active assignment can receive it. Later draft edits do not change the version already assigned.

### Track training progress

Find incomplete, completed and overdue learning.

Route: `/learning-centre#progress`

1. Open Learning centre → Progress reports with training-report access.
2. Filter by person, course, location or status and review due/completion dates.
3. Export CSV for the permitted filtered work.
4. Use Reporting → Training for cross-location progress and rankings when you also have reporting access.

## Knowledge Library

### Find and read Knowledge Library articles

Browse policies, information and embedded media.

Route: `/knowledge-library`

1. Open Knowledge Library and search a title or words inside an article.
2. Filter by Policies or Information, audience and category.
3. Choose Cards, List or Grid and open the article.
4. Follow headings, expand accordions and open the permitted images, documents or videos you need.

- Company articles follow the selected company; permitted network articles appear across companies. The shared platform search can also open matching article sections.

### Write and publish a Library article

Share reviewed information with the correct audience.

Route: `/knowledge-library`

1. Open Knowledge Library with publishing permission and create or edit an article.
2. Choose its title, Policies/Information type, category and company or authorised network audience.
3. Use the formatting editor to add text, tables, media, accordions or callouts.
4. Review the article and save/publish through its ordinary editor action. Refresh if another editor changed its revision.

- OpStack intelligence can prepare reviewed text inside the editor. It does not publish the article for you.

### Organise Library categories and views

Help staff browse related information.

Route: `/knowledge-library`

1. Use the Categories sidebar to choose All categories, Uncategorised or a saved category.
2. With publishing authority, choose Manage categories to add, rename or remove one.
3. Select the appropriate category while editing an article.
4. Use the sidebar arrow to collapse it and choose Cards, List or Grid for the results.

- Removing a category keeps its articles as Uncategorised. The sidebar and view choices are remembered for your user and company in this browser.

## Comms

### Send direct messages and create group chats

Talk to the people you share access with.

Route: `/communications`

1. Open Comms → Direct messages, expand search and select a person.
2. Write your message. Enter sends; Shift+Enter adds a line.
3. Use Group chats → Create group to name a group and choose participants when permitted.
4. Pin useful conversations or react to messages using the reaction control.

- On phones and tablets, an open conversation fills the screen; Back returns to the list. Only participants can read a private chat. In structured blocks, use Ctrl/⌘+Enter to send.

### Publish company or network posts

Share an update with the intended audience.

Route: `/communications`

1. Open Comms and choose the relevant posts view.
2. Create a post with the available company or network publishing permission.
3. Write and format the content, check the audience and decide whether acknowledgement is required.
4. Publish explicitly. Use your post’s edit/delete controls or Read receipts to review it later.

- Editing a required post creates a version that its audience must acknowledge again. Network publishing requires separate network authority.

### Add formatting, images, files and video

Use the shared editor in Comms, articles and lessons.

1. Use the compact toolbar for text formatting, safe links and emoji.
2. Open Insert for headings, lists, tables, accordions, quotes and dividers.
3. Choose Media for images, galleries, video/audio, documents or supported video embeds, then check captions.
4. Use callouts for important information and Undo/redo to review changes before saving or sending.

- Select text in the writing field to format it with the toolbar beside your selection. Alt+F10 opens it from the keyboard; Escape returns to the field.
- In post, article and lesson editors, Text style opens Normal text and Heading 1–3 directly. Insert also keeps the full formatting and media options.
- Uploaded video supports up to 25 MB; most other files support up to 10 MB each. Access to attached files follows the saved chat, article, course or post audience.

### Read or snooze required announcements

Handle an important update before continuing work.

1. Read the post shown over the app.
2. Choose Mark as read & continue to acknowledge that version.
3. If you need to finish something first, choose Snooze for 5 minutes.
4. Handle each outstanding post separately. The prompt returns when its snooze expires.

- Required reading can apply across your accessible companies. Refreshing or signing in again does not acknowledge it. Even users without normal Comms access can acknowledge a required post.

## Reporting

### Understand overall business performance

Read sales, costs, profit and margin for the chosen period.

Route: `/reporting#overview`

1. Open Reporting → Business overview and select a date range.
2. Choose locations when comparing stores, including accessible stores in other companies.
3. Review sales, total costs, profit, margin and data-completeness explanations.
4. Open a detailed report or week to investigate the figures behind the overview.

- Missing values differ from zero. Financial Cost of goods uses invoices and eligible net cost transfers; draft carts do not count. Platform fees stay separate.

### Compare and rank locations

Compare like-for-like dates and available data.

Route: `/reporting#overview`

1. In Reporting, select Compare locations and choose accessible stores.
2. Choose the report and ranking measure: financial sales/profit/margin or operational completion/overdue measures.
3. Apply the same dates, search and status filters across the comparison.
4. Review unranked locations for missing financial inputs or no matching work before drawing conclusions.

- Head Office Home also has a Sales leaderboard. Choose Daily and a date, or Weekly for completed days of the selected week. Complete saved revenue ranks from highest to lowest; gold, silver and bronze mark places 1–3. Missing days remain unranked with coverage shown. Tied results share a rank. Reporting’s location selection does not switch the location used elsewhere in the app.

### Report on training and checklists

See completion, overdue work and location comparisons.

Route: `/reporting#training`

1. Open Reporting and choose Training or Checklists.
2. Select dates, accessible locations and any staff/course/checklist/status filters.
3. Review completion rates, completed work and overdue totals, then compare locations if useful.
4. Use the displayed date rules when checking what is included and export the filtered results.

- Training needs training-report access in each selected company. Checklist reporting retains planner audiences. Today’s eligible unstarted checklists may appear; historical unstarted work cannot be recreated from current planners.

### Choose detailed reports and financial date rules

Trace overview totals to their source records.

Route: `/reporting#overview`

1. Use Reporting’s Report selector for financial performance, sales reconciliation, expenses, platform fees, invoices, order lines, count details or usage cycles.
2. Use Filters and tools for advanced filters, grouping and completeness checks.
3. For weekly financial records, review Financial week basis: weeks ending in the period or all weeks touching it.
4. Select View or a chart bar to inspect the corresponding week and source detail.

- Weekly costs are kept as full weekly amounts rather than invented daily allocations. Complete usage cycles need both opening and following closing counts.

### Export, sort and print reports

Share the complete filtered result rather than one page.

Route: `/reporting#overview`

1. Select the report, dates, locations and filters.
2. Sort with table headings and choose visible Columns.
3. Choose Export CSV for all filtered rows and fields, including rows beyond the current page.
4. Choose Print / PDF for all filtered pages with selected columns, or Export all details for the broader dated location data.

- Export all details keeps dates and locations but does not apply the current search/category/completeness filters. Check the selected scope before sharing.

### Schedule intelligence reports and read the inbox

Deliver reviewed report schedules by email and in the app.

Route: `/reporting`

1. Configure company intelligence and the sending location’s email settings first.
2. Open Reporting → AI reports and create a daily, weekly or monthly report.
3. Select topics, locations, the focus and recipients by users or permission levels. Generate and review a preview.
4. Save the enabled schedule. Scheduled runs deliver to eligible recipients by email and the Report inbox.
5. Open Report inbox to read delivered reports; edit or pause a schedule to change future runs.

- There is no manual Send action. Previewing uses an intelligence request but sends nothing. Recipient/source permissions are checked on each run; schedules use Melbourne time and the same company allowance.

## OpStack intelligence

### Connect OpStack intelligence

Set a company’s OpenAI key, budget and request allowance.

Route: `/settings#ai`

1. Select the intended company, then open blue account dropdown → Settings → OpStack intelligence.
2. Add an OpenAI API key with access to GPT-4.1 mini.
3. Choose the estimated monthly USD budget and request cap, enable intelligence and save.
4. Review Cost estimates and billing against your provider’s current prices and billing controls.

- Each company has separate settings. The key stays on the server and saving settings makes no provider request. A ChatGPT subscription does not include API usage. Estimated app limits are not a guarantee of the final OpenAI bill.

### Understand intelligence usage and limits

Know when a paid request happens and how previews are used.

1. Review the selected company’s allowance in Settings → OpStack intelligence.
2. Only submit content you intend the provider to process; inspect the source and selected pages first.
3. Review generated facts, procedures, answers and numbers before applying a preview.
4. Use the ordinary editor save, publish, assignment or import action after applying a reviewed preview.

- Limits reset monthly in Melbourne time. Uncertain provider failures may retain reserved estimated usage. Repeated uncertain failures should be investigated before starting another request. Ordinary editing and forecast calculations remain available when intelligence is disabled.

### Draft a checklist with intelligence

Turn submitted requirements into an editable checklist draft.

Route: `/ops-management#templates`

1. Open Checklist builder’s OpStack intelligence action with checklist-authoring permission.
2. Describe the checklist and review any reference notes you paste.
3. Generate and inspect the proposed instructions and response steps.
4. Choose Open draft in builder to create an ordinary editable draft, then review its planners and audience before activation.

- Generation is a preview. It does not start work or activate schedules.

### Generate a checklist plan

Ask for one repeating plan or a plan around trading hours.

Route: `/ops-management#templates`

1. Open a checklist’s Plans stage and choose OpStack intelligence plan.
2. Describe the plan, such as “repeat hourly from opening until closing”. Each checklist has one planner.
3. Review the start date, recurrence and timing, then choose Apply paused plan. This creates the first planner or updates the existing one in place, paused for review.
4. Check Locations, Assignees and saved trading hours, then activate the planner when ready. Existing locations and assignees are retained when intelligence updates its settings.

- Hourly recurrence creates its own hourly occurrences; a separate planner per clock hour is unnecessary. Suggestions contain one paused planner and never add an end date.

### Generate training questions from content

Create any of the nine question types from approved written sources.

Route: `/learning-centre#builder`

1. Open OpStack intelligence questions in Course builder or Add a block → Knowledge checks.
2. Choose written course content, accessible Knowledge Library articles or pasted text, then inspect the selected source.
3. Choose question types and a count large enough for each selected type. Generate and review questions and answers.
4. Choose Add questions to course to insert editable draft questions, then verify and publish through the normal course workflow.

- Generate up to 20 questions at a time within the course limit. Source selection excludes existing answer keys and media. Changed Library articles may need refreshing.

### Draft Comms and Library content

Write, improve or summarise submitted text inside the editor.

1. Open a permitted chat, post or article editor and choose OpStack intelligence.
2. Choose Draft new content, Improve existing text or Summarise source text.
3. Check the visible source field and instructions before generating.
4. Review the result and choose Use in editor, adding below or explicitly replacing text.
5. Use the editor’s ordinary Send, Publish or Save action when ready.

- Only the submitted text is used, rather than the full chat history or attached media. The original audience and publishing choice remain yours.

### Use intelligence to help read an invoice

Automatically read uploaded invoices, then check the results.

Route: `/home`

1. Upload an invoice on Home. OpStack intelligence reads it automatically when enabled and permitted, using the company allowance.
2. Review the extracted supplier, invoice number, invoice date, GST, total and any warnings against the original. Unique company supplier names are matched automatically.
3. For another read, open Read again or choose pages → OpStack intelligence. Review the text and up to three page numbers before pressing Read invoice.
4. Compare any new transcription with the original, then choose Use reviewed details. Correct any missing or unclear values in Invoice details.
5. Save the invoice and explicitly confirm any price updates through the normal actions.

- Each new upload requests one automatic read. Reopening saved invoices does not generate or use the allowance. Failed reads retain local results and are not automatically retried. Longer PDFs use images of the first two and last pages plus bounded local text; check the original for omitted sections. Intelligence never saves invoices or updates prices by itself.

### Choose intelligence colours and tint

Give intelligence controls a separate visual identity.

Route: `/settings#ai`

1. Open Settings → OpStack intelligence in the selected company.
2. Choose one of the five palettes and adjust tint depth from 100% to 160%.
3. Review the local preview, then use the existing Save action.
4. Check the search bar, intelligence menus and headers in your preferred theme.

- Intelligence uses its own font, gradients, shimmer and interaction glow. Reduced-motion settings keep decorative effects static. Appearance previews do not make provider requests.

## Locations & settings

### Create, archive or restore a location

Keep one active list sectioned by Australian state.

Route: `/admin/accounts#locations`

1. Open Admin → Locations and choose Add location, or edit an existing row.
2. Set its name, state and Target level system for all stock items. Use Employer setup for legal employer and pay settings, then Save settings.
3. Use the archive action for an inactive location when permitted.
4. Open the separate Archived locations menu to find or restore archived stores.

- Head Office can be created or opened from the location selector without setup. Its administrative location has no store-settings tabs. Active locations remain one list with state sections. Archiving keeps saved settings and history; native restrictions may prevent archiving a location still in use.

### Complete a new location’s setup checklist

Finish the setup tasks inside the popup.

Route: `/admin/accounts#locations`

1. Create a location and open its highlighted setup entry or reminder.
2. Complete name, state, trading hours, location manager, first user, employer setup, ordering email, Target level system and a new kiosk.
3. Open each step inside the popup. Target level system chooses one method for all stock and offers manual fallback or item sales quantities. Partial saves retain unfinished entries.
4. Finish setup once every task is validated. Snooze the reminder for five minutes if needed.

- Head Office is exempt from this store setup checklist and its reminders. Setup is non-blocking. Pending locations stay highlighted and tinted until completion. Kiosk setup creates a new device for this store rather than listing other stores’ devices.

### Set trading hours and overnight closing

Save all seven days with closed and unknown days distinguished.

Route: `/admin/accounts#locations`

1. Open Edit location → Trading hours.
2. Enter opening and closing in AM/PM or 24-hour text. Use Copy Monday to all if helpful, then adjust individual days.
3. Choose Closed for a non-trading day. Leave both fields blank only when the hours are not set.
4. Press Save settings for the location popup.

- 11 am–4 am closes the following day. Equal opening and closing means 24 hours. These hours support overnight sales, hourly-report conversion and trading-hours checklist planners.

### Assign location managers

Choose the people responsible for a store.

Route: `/admin/accounts#locations`

1. Open Edit location → Managers with location and user-management authority.
2. Select eligible existing users and the permitted company permission level.
3. Press the single Save settings action.
4. Check manager names on the location list and Home. Affected users may need to sign in again.

- Manager assignments and the Manager Home dashboard are separate settings. Assigning a location manager enables eligibility for Home transfer approvals when the account also has receipt permissions.

### Manage companies and separate their settings

Keep catalogues, appearance and locations organised by company.

Route: `/admin/accounts#companies`

1. Open Admin → Companies with company-management authority and choose Add company.
2. Create its first location and rename company details as needed.
3. Switch to the company through the logo picker before adding its suppliers, stock and appearance.
4. Give users the required location memberships and company permission assignments.

- New companies start with an empty catalogue. A company must retain an active location. Intelligence keys and budgets are also company-specific.

### Create or edit users

Set up a user with a guided checklist, permissions and roster details.

Route: `/admin/accounts#accounts`

1. Open Admin → Users and choose Create user. The User setup popup tracks each step as you complete it.
2. Set up Name & email, then Phone & clock PIN. Add their phone number for clock/kiosk access, or choose Skip for now. The last four phone digits must be unique across the network.
3. Review Permissions, including whether they apply to this company or the network, then choose accessible Locations and a default location.
4. Choose Review invitation, check the details and press Send invitation. Only this action creates the account and sends its password setup link. Check the delivery result.
5. After invitation, open Roster details. Choose employment type, classification and allowances. Check Pay Rates and Roster setup, complete missing details and Save employment details. Part-time costs need written regular hours or a current signed roster-hours IFA. Review and send selected employment documents separately. Continue when saved setup is ready for today, then Finish user setup; Skip for now leaves roster details for later.
6. Use the pencil beside a user to open their User settings popup, then choose Personal, Pay Conditions, Time & Attendance or Leave & Availability. Groups keep unsaved fields; Close or Escape asks before discarding them. Save account details, photos and employment terms with their own Save actions. Sign in again after access or sign-in changes.

- You can only manage users and grant access within your own authority. Closing User setup before inviting retains the draft on this page; Discard draft clears it. Roster records are separate from account permissions. Pay Rates requires the location employer’s automatic award calculations to be enabled; the Roster setup check shows missing employer, employment or state details. State public holidays price roster estimates automatically; actual payroll holidays still need review. New users choose their own password; existing sign-ins continue to work. Roster setup does not create shifts or availability.

### Set staff allowances during onboarding

Save allowance choices in the employee’s Pay Conditions.

Route: `/settings/awards`

1. After inviting a user, open Roster details in User setup. For an existing employee, open Users → pencil → Pay Conditions.
2. Open Allowances and tick the applicable choices. Uniform laundry applies automatically; cold work, vehicle use, extra travel, overtime meals and expense reimbursements depend on actual work.
3. Check the Pay Rates preview and press Save employment details. Selections use the employment effective date and remain available when editing later.
4. Build the roster using the saved staff settings. Confirm variable quantities and meal conditions in Timesheets → Pay details → Actual allowance details and reimbursements, with a reason, before approval.

- Selecting a conditional allowance does not invent hours, kilometres, expenses or meal eligibility. Unselected work conditions do not waive an allowance owed under the award. Laundry retains the native weekly/per-engagement calculation, and Broken Hill follows the location calendar. Existing recorded shift facts and approved pay snapshots are retained.

### Send account setup invitations

Let new users set up access through an expiring invitation.

Route: `/admin/accounts#accounts`

1. Configure the shared account setup email sender in the available Settings or Opstack-owner controls.
2. In Users, choose Create user and complete the Name & email, optional Phone & clock PIN, Permissions and Locations steps in User setup.
3. Choose Review invitation and press Send invitation, then check the delivery result. Continue to the new user’s roster details or finish them later.
4. The recipient opens the setup link and chooses a unique password of 15–256 characters. Several unrelated words work well; common or repeated passwords are rejected. For a failed or expired invitation, edit the existing user and choose Resend setup email. An unconfirmed send should be checked with the email service first.

- Existing passwords keep working and receive stronger storage after a successful sign-in. Repeated incorrect attempts temporarily restrict sign-in for 15 minutes. Never share passwords or staff accounts. Hosted network account-email settings may be managed by the Opstack owner. Ask the appropriate administrator if this control is unavailable. Setup emails use the shared account sender, separate from location ordering emails.

### Choose detailed permission levels

Control feature access and individual actions separately from the Staff/Manager Home dashboard.

Route: `/settings#permissions`

1. Open Settings → Permission levels. Search existing levels, edit one within your authority, or choose Duplicate to start from its current settings.
2. Set the name, optional description and hierarchy. Choose Staff or Manager / Supervisor Home; sales access elsewhere remains a separate permission.
3. Use Find a permission and Show to review grouped feature grants and detailed actions. For example, allow Place orders and Edit placed orders while leaving Delete orders off. Required view permissions are selected automatically.
4. Choose This company only or, when authorised, Entire network. Press Save permission level to apply the reviewed settings. Network publishing replaces company customisations of that level.
5. Assign the saved level through Admin → Users. Check its feature access and detailed actions; changes apply to assigned users immediately.

- The 36 detailed actions cover saved orders, report imports, invoice uploads/removal, stock/supplier/user/location/company actions, kiosks, course publishing/archiving, planners, rosters, report exports, company article removal, email templates and individual intelligence tools. Existing levels retain their access until changed. Detailed actions require their underlying feature grants; they do not grant access to other companies or locations. You cannot grant more authority than you hold. In-use levels cannot be deleted and the final full network owner is protected. Cancel and Duplicate do not save anything.

### Add, pair or revoke a kiosk device

Connect a shared device to one location.

Route: `/settings/devices`

1. Open Settings → Kiosk devices or the location’s Devices tab.
2. Create a new named kiosk for the intended location and obtain its expiring single-use pairing code.
3. Open the kiosk page on that device and enter the pairing details.
4. Test staff PIN access. Revoke the device from management when it should no longer be trusted.

- Pairing fixes its company/location and does not grant staff extra permissions. Browser fullscreen and operating-system kiosk lockdown are separate device settings.

### Set up a location’s order-sending email

Connect the sender address and sending service for supplier orders.

Route: `/admin/accounts#locations`

1. Open Admin → Locations → Edit location → Sending for the intended store.
2. Enter its sender email and Resend API key, and enable automatic supplier emails.
3. Press Save settings and check the saved sending status.
4. In Suppliers & delivery, separately set each supplier to Email and save the recipient.

- Use a sender authorised by your Resend account. An order confirmation is also sent separately to the location’s sender when its email sending is enabled. Keys should only be entered in the protected settings form.

### Understand confirmation emails to the sender

Review the separate receipt of a placed order.

1. Configure the location’s enabled order-sending settings and sender address.
2. Place and confirm an order through the ordinary cart workflow.
3. Check the sender mailbox for the separate order confirmation and review the app’s supplier sending outcomes.
4. Use Order history as the saved record if the confirmation email fails.

- The confirmation reports supplier outcomes and estimated prices. It does not prove supplier acceptance or appear automatically in the sender mailbox’s Sent folder. Recording a past order does not send it.

### Customise supplier order emails

Review the company’s template before using it for new orders.

Route: `/settings#order-email`

1. Open Settings → Order email template in the intended company.
2. Edit the available layout and supported template fields, including company details where offered.
3. Review the preview and save the template.
4. Use the normal reviewed order flow for future orders.

- Template edits do not resend past emails or change saved order quantities. Sender and recipient configuration remains separate.

### Change company appearance

Set company colours, logos and fonts in the correct scope.

Route: `/admin/settings#colours`

1. Select the company, then open the blue account dropdown → Settings → App appearance.
2. In Colours, choose Standard or Liquid Glass under Interface style and review the sample. Liquid Glass makes navigation, cards, buttons, fields and popups clear. Change company colours, app/sidebar logos or available font settings as needed.
3. Save the section’s settings and check an ordinary app page in both themes.
4. Use authorised shared sign-in controls only when changing the platform’s sign-in appearance.

- Liquid Glass replaces flat control and panel fills with clear surfaces while keeping company text colours, page artwork and intelligence accents. Choose Standard to restore saved fills and intelligence tints. Company appearance is separate from shared platform sign-in settings.

### Edit Home sections and app appearance in place

Arrange supported surfaces with desktop App edit.

Route: `/home`

1. On a computer with appearance permission, open the blue dropdown and choose App edit.
2. Configure or rearrange supported Home sections and their dimensions. Staff and Manager Home keep separate section layouts.
3. Select supported surfaces for appearance changes. Select the Home greeting to change its wording while keeping {user} exactly once.
4. Review saved changes, use Undo if needed and choose Finish editing.

- Choose Head Office from the location selector before editing its dashboard. Creating Head Office needs no store setup. App edit is suspended on phones. Ordinary words, numbers and form inputs are not individual editable appearance targets.

### Configure employment and award estimates

Review the settings used by native wage calculations.

Route: `/settings/awards`

1. Open Settings → Award compliance. Overview shows Employer, Employees and Public holidays for each accessible trading location.
2. Choose Open setup for the location. Enter the legal employer and pay period, confirm award coverage and turn on automatic award wages, then Save settings. Optional employer cost estimates are expandable.
3. Expand Employee details → Edit details. Choose employment type, classification and allowances; Pay Rates underneath updates without saving. Add regular working hours is optional during setup; complete part-time costs need written hours or a current signed IFA permitting roster-based hours. Press Save employment details and check Roster setup ready. The location state supplies automatic roster holiday estimates.
4. Before approving actual pay, choose Review dates. Check the full year’s holidays, including local, substitute and part-day periods; expand All day to edit times when needed. Confirm the review and Save location calendar.
5. Roster building has no award review or publication review note. Missing pay setup is explained in shift Costs. Allowances are selected during staff setup and Pay Conditions. In Timesheets, use Pay details for actual allowance quantities, breaks or written variations. Missing wage inputs must be completed. Advanced rules and source details remain available for reviewed updates.

- Setup readiness is not a compliance certificate. The calculator uses the included July 2026 edition. Special arrangements, classifications, regional exceptions, payroll and later award changes need employer review. Each saved location retains separate employer settings. Approved calculations stay frozen until explicitly reopened.

### Record an Individual Flexibility Agreement (IFA)

Keep a signed employer agreement with the employee’s dated Pay Conditions.

Route: `/settings/awards`

1. Select the employee’s employer location. Open their Pay Conditions in Users, or Award compliance → Employee details → Edit details.
2. Choose Add Individual Flexibility Agreement (IFA). Record the retained signed agreement reference, signing date, start date and any end date. The employer comes from this location’s Employer setup.
3. Select the terms the signed agreement varies. If it permits rostered hours instead of fixed regular hours, select When work is performed and confirm that specific permission. Record what changes and the better-off-overall assessment.
4. Confirm the required signatures, including a parent or guardian for an employee under 18, and that the original is retained and the employee received a copy. Press Save employment details. Choosing or previewing fields does not save.
5. A current working-hours-only IFA allows part-time costs without fixed regular hours at that employer location. Actual hours use the published roster; time outside it attracts overtime. Standard award limits and pay rules remain. Other varied pay terms require separate review.

- Recording an IFA does not create or sign an agreement, establish employee consent or certify that the employee is better off overall. Keep the signed original in employer records. IFAs are limited to the recorded employer location and dates; future, ended or different-employer agreements do not remove the fixed-hours requirement. One-off written part-time shift variations remain optional and are separate from an IFA. Approved costs remain frozen until reopened.

### Send and sign employment agreements

Prepare reviewed contracts and IFAs, then collect signatures through each person’s own OpStack account.

Route: `/employment-documents`

1. Invite the employee through Users first. Save their Pay Conditions and set up the location’s legal employer and platform Account setup emails sender. Staff must activate their own account before signing.
2. Open Users → edit staff → Pay Conditions → Employment documents. Select the reviewed contract, IFA or both. OpStack fills saved staff and employer details, employment type and available native pay rates. Confirm legal names and the effective date; missing required fields must be completed in saved settings.
3. Choose Review selected documents, read each exact filled document and press Send selected documents. All selected versions become fixed and each named signer is emailed. These documents also become account-onboarding tasks. A lost response uses Retry the same send without creating duplicate documents.
4. Staff activate their invited account and sign in. Pending employee signatures open their onboarding page and appear in Home → Your work. Open the agreement, read or download it, request an email code and verify it. Codes expire after ten minutes; verification does not sign.
5. Type the full legal name shown for your account’s signing role. Confirm electronic consent and intention, then Sign agreement → Confirm signature. Required guardians use their own separate accounts; IFAs for employees under 18 require that signature too. You may decline or request paper signing without consenting to an electronic signature.
6. When all named parties have signed, download the completed copy and signing record from My agreements. Every party is also emailed a completed copy. Browser print can save the downloaded HTML copy as PDF. Provider acceptance is not proof of email delivery; completed copies remain available in the app.

- The first version supports reviewed plain-text ordinary employment agreements, not PDF uploads, deeds, witnessing or special execution. Each signer must have their own OpStack account; shared kiosks and support impersonation cannot sign. Account login plus email verification proves account/email access, not government identity. IFAs can only be signed after employment has commenced. Document review and legal validity remain separate from signing evidence; the app does not certify terms or automatically change award profiles, regular hours, wages or permission levels. Completed records cannot be edited or deleted through the app. Paper requests do not force digital consent.

### Create contract and IFA templates

Use an email-style editor with staff fields and a live document preview.

Route: `/admin/accounts#accounts`

1. Open Users → edit staff → Pay Conditions → Employment documents → Edit contract & IFA templates. Company-wide user and employment access is required to edit shared templates; authorised location managers can select reviewed templates.
2. Choose New contract template or New IFA template. Give it a clear name, select its agreement type and enter the document title and complete independently reviewed terms.
3. Focus the title or agreement text, then use Insert staff field. Fields include staff name, email, legal employer, location, dates, employment type, classification and available award rates. The live preview uses the selected employee’s saved details; example previews are labelled. Missing values are never guessed.
4. Enter the legal / employment review reference, confirm ordinary execution requirements and mark Reviewed and ready to use. Save template. Unreviewed drafts cannot be sent; editing terms clears readiness until reviewed again. Archive retires a template while retaining issued documents and signatures.
5. Return to Pay Conditions, save any staff or pay changes, then select the contract, IFA or both. Review selected documents shows the exact filled text before Send selected documents. Updated staff, pay or template details require a fresh review. IFAs for minors need a separate guardian account.

- Templates contain reviewed ordinary agreement text, not automatically approved legal terms. Saving templates, opening previews and saving pay details never sends contracts or applies IFA pay terms. Shared templates are company-specific; later edits never rewrite issued documents. My agreements retains individual drafts and signing history.

### Use the Opstack owner and support console

Manage networks using a separate platform account.

1. Open Opstack console from the account dropdown and sign in with your Opstack owner or support credentials.
2. An owner can create a network after configuring shared account emails, then enter its code, company, location and first Head Office user.
3. Use Open network to enter with your own support identity. The orange support indicator links back to the console.
4. Owners manage platform accounts and network suspension; review Activity for platform actions.

- Opstack accounts are separate from company users. A Head Office permission level does not create platform-owner access. Support cannot view private chats unless it is a participant.

### Manage platform defaults and account setup emails

Set shared platform options with an Opstack owner account.

1. Sign in to Opstack console as an owner and open the relevant shared settings.
2. In Account setup emails, configure the verified sender, Resend key, enablement and welcome template, then save.
3. Use New network defaults for future starting colours, font, welcome and greeting; retain {user} once in the greeting.
4. Use Platform appearance for shared sign-in branding. Review which scope is affected before saving.

- New defaults affect future network snapshots, preserving existing company customisations. Shared account invitations are separate from location supplier-order sending.

### Review the Opstack monthly report

Review recurring billing estimates, invoice results and platform expenses.

1. As an OpStack owner, open Console → Monthly report and select a month. Sales shows recurring estimates, Expenses records platform costs and Collections shows imported payment results.
2. Stripe-linked locations show saved monthly location fees plus allocated user fees. Historical counts are not guessed. Unlinked locations keep manual fees; edit those to set a fee from the selected month onwards.
3. In Expenses, enter the month’s named costs and choose Save expenses. Save or reload drafts before changing the month.
4. Open Collections and choose Stripe Live or Sandbox. Paid invoices use their Melbourne payment month; refunds use their creation month. These are invoice results, not bank reconciliation or GST reporting. Archived GoCardless history remains read-only.

- This owner-only report is separate from tenant sales, ordering and payroll. Recurring estimates exclude invoice adjustments and tax additions; inspect Collections and Stripe for actual amounts.

### Connect Stripe location and user billing

Follow five saved steps to connect Stripe and start approved location billing.

Route: `/opstack#billing`

1. Open Console → Billing as an OpStack owner. Choose Sandbox and follow Connect. Paste the Stripe secret test key, then Save & connect. This saves the key and tests it before continuing. Live has a separate connection. Saved progress resumes when you return.
2. In Notifications, copy the webhook address into Stripe’s webhook setup. Choose Your account and snapshot events; select the events listed under Events to select in Stripe. Paste the matching signing secret into OpStack, then Save & continue. If the address is blank, set APP_ORIGIN to the public HTTPS app address and redeploy first.
3. In Location, add a location and Load prices from Stripe. Choose its AUD monthly location and per-user fees. Create the paying customer here or select a saved customer, then Save & continue. Other locations paid by that business can reuse it. Existing reference IDs and subscriptions remain under Advanced.
4. In Checkout, Review checkout and check the fees, user count and tax treatment before creating a link. Open or copy the secure link for the customer to finish Stripe checkout. Choose Done, then Check checkout status. Sandbox test card details are in the expander. The linked subscription moves you to the final step.
5. In Automatic updates, choose Review & enable updates. Check the current amounts and select Approve & enable updates. This approves the location quantities and turns on updates for approved plans with automatic updates selected. Changes prorate on the next invoice. Review payment results in Monthly report → Collections; select Sandbox for test data.

- Continue saves each completed step. Back and step buttons retain unsaved fields; use Save progress to save without moving on. Browsing steps never calls Stripe. Creating a customer does not start billing. Unknown write outcomes retain exact retries. Configure Stripe Tax registrations before enabling tax. Turning off sync does not cancel subscriptions; stop old GoCardless subscriptions there before starting live Stripe billing. Invoice results remain separate from bank payouts and GST returns.

## Labels

### Prepare and print prep labels

Check calculated label details before printing.

Route: `/labels`

1. Open Labels, filter by category and select a template card.
2. Fill any On Print or On Label fields, check ready/discard times and choose quantity.
3. Review the complete label preview and selected media settings.
4. Use the available print/download action and confirm the physical output on your printer.

- Creating a print batch does not prove a physical printer delivered it. Saved templates determine shelf-life rules; check them before use.

### Design label templates and printer settings

Build company templates using the actual paper size.

Route: `/labels`

1. In Labels, choose Add label template or edit through a template’s menu.
2. Choose its category, name and company-approved timing rules.
3. Add fields on the canvas, move or resize them and edit their properties. Use Done for a field and Save for the template.
4. Configure the printer/media resolution and test a preview before normal printing.

- The default Zebra media is 50 × 25 mm at 203 dpi. Explicitly configure other media/resolutions. Template edits do not rewrite old print batches.

### Review printed label batches

Find the recorded template and values used for a batch.

Route: `/labels`

1. Open Labels → History at the relevant location.
2. Find the batch and review its saved label details and timing.
3. Use the available reprint/download controls when appropriate and recheck the physical label.

- History retains fixed batch snapshots even when templates change later.

## Troubleshooting & support

### A label previews but does not print correctly

Check the device’s print setup and actual media.

1. Use the label preview to confirm the template, preparation date, quantity and printer/media settings.
2. In the system print dialog, select the installed printer, matching paper size, 100%/actual scale, no headers or footers and zero margins.
3. For a Zebra-file workflow, download the ZPL and send it through your installed Zebra software or configured print service.
4. Check the physical label for media calibration, resolution and margins. Ask your device administrator if no printer is available.

- Phone printing needs a compatible system printer or print service. A saved batch or downloaded file does not itself confirm physical printing.

### An order saved but the supplier email did not send

Check sender settings, recipient details and the actual outcome.

1. Open the saved order and read each supplier’s delivery message before placing anything again.
2. Check the correct location’s Sending tab: sender, saved Resend key and Enable automatic supplier emails.
3. Check the selected company’s supplier → Order delivery: Email and the correct saved recipient.
4. Review the sending provider’s dashboard for rejected addresses, sender verification or API errors.
5. If you place the order outside the app, use Confirm ordered in Delivery tracking and set its expected date.

- Do not repeatedly submit a saved order to test email. It can create duplicate supplier orders. A “not configured” message means a required sending setting was unavailable to that order.

### Saved daily sales seem to be missing

Check the trading date and the separate sales stores.

1. Confirm the selected company and location match where you saved.
2. Use Home’s Daily sales history link to open the exact trading week, especially after midnight or early Monday.
3. Look in Sales → Daily sales rather than assuming it fills Weekly report.
4. If the save is still missing, note the displayed date, save confirmation and location, then prepare a support request.

### A scan has not appeared in Hourly sales

Finish review and explicitly submit the extracted hours.

1. Keep the scan popup open and check the extracted dates and hourly values.
2. Resolve warnings and choose Trading day or Calendar day if required.
3. Press Submit hourly sales and read the message beside it. A scan preview alone is not a saved import.
4. Check the earliest imported date in Hourly sales. Existing differing hours may have been skipped unless replacement was explicitly selected.

### A page or action is missing

Check permissions, audience and the current location.

1. Check your current company and location in the header.
2. Open User profile to review your current role and accessible locations.
3. Ask an authorised user manager to review the matching view/edit/manage permission and your location memberships.
4. For courses, checklists or Library content, also check the assignment or audience. Sign in again after account changes.

- Choosing Manager Home does not grant sales or management access. Help guides describe all features; their screen links are offered only when your current permissions allow them.

### Your PIN or clock action is unavailable

Check the saved phone ending, published shift and current stage.

1. Ask a user manager to open your Personal settings and verify your phone number. Time & Attendance shows the clock PIN from its unique last four digits.
2. Check that the shift is assigned, published, at this location and on the correct Melbourne day.
3. Use the action offered for the current work/break stage. Early starts require a different authorised manager’s approval.
4. After repeated wrong PINs, allow the limit to expire or ask a user manager to reset PIN access by saving the phone number again.

- Five incorrect PIN attempts cause a 15-minute limit. Missing or unrostered work can be submitted for review as a manual timesheet with a reason.

### Intelligence is disabled or a request failed

Check the selected company’s setup and allowance.

1. Ask an intelligence-settings manager to check the selected company’s saved key, enablement, budget and request cap.
2. Check the provider account has API billing and access to the configured model.
3. Review the error and keep your source or editor draft. Use ordinary manual editing if generation is unavailable.
4. For an uncertain failed request, investigate before starting another request, since estimated usage may already be reserved.

### Scheduled reports are not arriving

Check schedule, sender and recipient access.

1. Open Reporting → AI reports and confirm the schedule is enabled and its Melbourne due time has passed.
2. Check company intelligence allowance and the selected sending location’s email setup.
3. Review recipient selection and each recipient’s current company, location and source access.
4. Check Report inbox and the email provider’s status. Capture the run’s visible error for support.

### A save reports a conflict or loses connection

Preserve your draft and resolve the actual saved state.

1. Keep the editor open and read its save message. Record or copy unsaved work before reloading.
2. If another user changed the record, reload the latest saved version and reapply the intended changes.
3. If the result is uncertain and the form offers Retry, retry that same action rather than creating a second order, receipt or import.
4. For location or stock settings with partial saves, review which sections succeeded and retry only the remaining draft.

### Get help from your manager or support contact

Prepare useful details about a problem.

1. Search this help centre for the feature or exact error first.
2. Note the company, location, page, local time and what you expected to happen.
3. Include the visible error and relevant order reference or report date. Capture a screenshot if it helps.
4. Use Copy support details below for a starting template, then contact your manager through Comms or your organisation’s usual support channel.

- Copying details prepares text; it does not submit a ticket. Keep API keys, passwords and PINs out of messages and screenshots.
