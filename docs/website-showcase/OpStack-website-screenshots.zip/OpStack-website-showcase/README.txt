OpStack website screenshot pack

10 genuine browser captures of the app using isolated demo data, not AI-generated UI. Existing app styling is preserved.

Desktop: 3200 x 2000 PNG (display at 1600 x 1000 or smaller for crisp 2x rendering).
Mobile: 780 x 1688 PNG (display at 390 x 844 or smaller).
Open index.html to browse and download individual images.

Suggested homepage hero: 01-store-dashboard.png with 10-mobile-sales.png. Feature sections: roster builder, ordering, timesheets, training, Knowledge Library, communications and reporting.

All names, values and transactions shown are demo examples. The screenshots show the current app, including features labelled Beta. No production accounts, employee information or credentials were used.
